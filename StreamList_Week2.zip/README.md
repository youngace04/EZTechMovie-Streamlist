# EZTechMovie StreamList - Week 2

## Features
- Navigation using React Router
- Add, Edit, Delete, and Complete items in StreamList
- Icons using React Icons
- Styled with CSS

## Setup Instructions
1. Clone the repository
2. Run `npm install`
3. Install React Icons: `npm install react-icons`
4. Start the app: `npm start`
