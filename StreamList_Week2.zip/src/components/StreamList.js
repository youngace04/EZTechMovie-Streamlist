import { useState } from 'react';
import { FaEdit, FaTrash, FaCheck } from 'react-icons/fa';
import './StreamList.css';

function StreamList() {
  const [item, setItem] = useState('');
  const [list, setList] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (item.trim() === '') return;

    if (editIndex !== null) {
      const updatedList = [...list];
      updatedList[editIndex].name = item;
      setList(updatedList);
      setEditIndex(null);
    } else {
      setList([...list, { name: item, completed: false }]);
    }
    setItem('');
  };

  const handleDelete = (index) => {
    setList(list.filter((_, i) => i !== index));
  };

  const handleEdit = (index) => {
    setItem(list[index].name);
    setEditIndex(index);
  };

  const handleComplete = (index) => {
    const updatedList = [...list];
    updatedList[index].completed = !updatedList[index].completed;
    setList(updatedList);
  };

  return (
    <div className="streamlist-container">
      <h1>Your StreamList</h1>
      <form onSubmit={handleSubmit} className="streamlist-form">
        <input
          type="text"
          value={item}
          onChange={(e) => setItem(e.target.value)}
          placeholder="Add a movie or show"
        />
        <button type="submit">{editIndex !== null ? 'Update' : 'Add'}</button>
      </form>
      <ul className="streamlist-items">
        {list.map((movie, index) => (
          <li key={index} className={movie.completed ? 'completed' : ''}>
            <span>{movie.name}</span>
            <div className="actions">
              <button onClick={() => handleEdit(index)} title="Edit"><FaEdit /></button>
              <button onClick={() => handleDelete(index)} title="Delete"><FaTrash /></button>
              <button onClick={() => handleComplete(index)} title="Complete"><FaCheck /></button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default StreamList;