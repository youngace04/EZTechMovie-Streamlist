function Component() { return <h1>Page Coming Soon</h1>; }
export default Component;